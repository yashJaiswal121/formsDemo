import React, { Component } from 'react';
import TextField from './TextField/TextField';
import RadioButton from './RadioButton/RadioButton';
import Select from './Select/Select';


class App extends Component {

  jsonObj={
    textFields:[{label:"Name",name:"inputField1",type:"text"},{label:"Age",name:"inputField2",type:"number"}],
    radioButtonGroups:[{label:"Gender",val1:"Male",val2:"Female"},{label:"Experience",val1:"Good",val2:"Very Good"}],
    buttons:[{label:"Submit",type:"submit"},{label:"SimpleBtn",val1:"button"}],
    selects:[{label:"Country",options:["India","U.S","China"],name:"countries"}],
};

constructor(props){
super(props);
this.state=this.jsonObj;

}



getTextField(typeObj) {
  
return <TextField label={typeObj.label} name={typeObj.name} type={typeObj.type} />;
  
}

getRadioButton(typeObj) {
  
  return <RadioButton label={typeObj.label} val1={typeObj.val1} val2={typeObj.val2} />;
    
  }
  getSelect(typeObj) {
  
    return <Select label={typeObj.label} options={typeObj.options} name={typeObj.name} />;
      
    }

  render() {

     
    return (
      <div className="App">
   
        {this.state.textFields.map(x=>this.getTextField(x))}
        {this.state.radioButtonGroups.map(x=>this.getRadioButton(x))}
        {this.state.selects.map(x=>this.getSelect(x))}


      
      </div>
   
    );
  }
}

export default App;
