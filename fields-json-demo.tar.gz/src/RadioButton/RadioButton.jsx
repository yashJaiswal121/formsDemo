import React,{Component} from 'react';
class RadioButton extends React.Component{

    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return(
            <div>
                {this.props.label}<br/>
                <input type = "radio"
                value = {this.props.val1} name={this.props.label} />{this.props.val1}<br/>
                 <input type = "radio"
                
                value = {this.props.val2} name={this.props.label} />{this.props.val2}<br/>


            </div>
        );

    }


}

export default RadioButton;