import React, { Component } from 'react';

class TextField extends React.Component{

    constructor(props){
        super(props);
        this.state={};
    }

    render(){
        return(
            <div>
                {this.props.label}
                <input type={this.props.type}  name={this.props.name}/>

            </div>
        );

    }


}

export default TextField;