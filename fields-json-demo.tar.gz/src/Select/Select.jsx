import React,{Component} from 'react';
class Select extends React.Component{

    constructor(props){
        super(props);
        this.state={};
    }

    getOption(optionn){
        return <option value={optionn}>{optionn}</option>;
    }
    
//  {this.getOption(this.props.valuesLength)}
    render(){
        return(
            <div>
                {this.props.label}
                <select  name={this.props.name}>
                {this.props.options.map(optionn=>this.getOption(optionn))}
                </select>
            </div>
        );

    }


}

export default Select;